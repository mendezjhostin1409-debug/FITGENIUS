const { pool } = require('../database/connection');

class Rutina {
  static async createTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS rutinas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_email VARCHAR(255),
        nombre VARCHAR(255) NOT NULL,
        nivel VARCHAR(50),
        categoria VARCHAR(50),
        tiempo_descanso INT,
        tiempo_estimado INT,
        ejercicios JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_email) REFERENCES users(email) ON DELETE CASCADE
      )
    `;
    await pool.query(query);
    console.log('✅ Tabla rutinas creada/verificada');
  }

  static async create(userEmail, rutinaData) {
  console.log('📝 Rutina.create - Usuario:', userEmail);
  console.log('📦 Datos a guardar:', JSON.stringify(rutinaData, null, 2));
  
  const { nombre, nivel, categoria, tiempoDescanso, tiempoEstimado, ejercicios } = rutinaData;
  const [result] = await pool.query(
    `INSERT INTO rutinas (user_email, nombre, nivel, categoria, tiempo_descanso, tiempo_estimado, ejercicios)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [userEmail, nombre, nivel, categoria, tiempoDescanso, tiempoEstimado, JSON.stringify(ejercicios)]
  );
  console.log('✅ Insertado ID:', result.insertId);
  return this.findById(result.insertId, userEmail);
}

  static async update(id, userEmail, rutinaData) {
    const { nombre, nivel, categoria, tiempoDescanso, tiempoEstimado, ejercicios } = rutinaData;
    const [result] = await pool.query(
      `UPDATE rutinas
       SET nombre = COALESCE(?, nombre),
           nivel = COALESCE(?, nivel),
           categoria = COALESCE(?, categoria),
           tiempo_descanso = COALESCE(?, tiempo_descanso),
           tiempo_estimado = COALESCE(?, tiempo_estimado),
           ejercicios = COALESCE(?, ejercicios)
       WHERE id = ? AND user_email = ?`,
      [
        nombre ?? null,
        nivel ?? null,
        categoria ?? null,
        tiempoDescanso ?? null,
        tiempoEstimado ?? null,
        ejercicios ? JSON.stringify(ejercicios) : null,
        id,
        userEmail,
      ]
    );
    if (result.affectedRows === 0) return null;
    return this.findById(id, userEmail);
  }

  static async findAllByUser(email) {
    const [rows] = await pool.query(
      'SELECT * FROM rutinas WHERE user_email = ? ORDER BY created_at DESC',
      [email]
    );
    return rows;
  }

  static async findById(id, userEmail) {
    const [rows] = await pool.query(
      'SELECT * FROM rutinas WHERE id = ? AND user_email = ?',
      [id, userEmail]
    );
    return rows[0];
  }

  static async delete(id, userEmail) {
    const [result] = await pool.query(
      'DELETE FROM rutinas WHERE id = ? AND user_email = ?',
      [id, userEmail]
    );
    return result.affectedRows > 0;
  }
}

module.exports = Rutina;
