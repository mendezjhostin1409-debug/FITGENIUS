const express = require('express');
const router = express.Router();
const Rutina = require('../models/Rutina');
const authMiddleware = require('../middleware/auth');

// Convierte una fila de la BD (snake_case) al formato que espera el frontend Flutter (camelCase)
function formatRutina(row) {
  if (!row) return null;
  let ejercicios = row.ejercicios;
  if (typeof ejercicios === 'string') {
    try { ejercicios = JSON.parse(ejercicios); } catch (e) { ejercicios = []; }
  }
  return {
    id: row.id,
    nombre: row.nombre,
    nivel: row.nivel,
    categoria: row.categoria,
    tiempoDescanso: row.tiempo_descanso,
    tiempoEstimado: row.tiempo_estimado,
    ejercicios: ejercicios || [],
  };
}

// OBTENER TODAS LAS RUTINAS
router.get('/', authMiddleware, async (req, res) => {
  console.log('📥 GET /api/rutinas - Usuario:', req.userEmail);
  try {
    const rutinas = await Rutina.findAllByUser(req.userEmail);
    console.log(`✅ ${rutinas.length} rutinas encontradas`);
    res.json(rutinas.map(formatRutina));
  } catch (error) {
    console.error('❌ Error al obtener rutinas:', error);
    res.status(500).json({ error: 'Error al obtener rutinas' });
  }
});

// CREAR NUEVA RUTINA
router.post('/', authMiddleware, async (req, res) => {
  console.log('📝 POST /api/rutinas - Usuario:', req.userEmail);
  console.log('📦 Datos recibidos:', JSON.stringify(req.body, null, 2));

  try {
    const { nombre, nivel, categoria, tiempoDescanso, tiempoEstimado, ejercicios } = req.body;

    if (!nombre || !ejercicios || ejercicios.length === 0) {
      console.log('❌ Error: Nombre o ejercicios faltantes');
      return res.status(400).json({ error: 'Nombre y ejercicios son obligatorios' });
    }

    console.log(`📝 Creando rutina: ${nombre} con ${ejercicios.length} ejercicios`);

    const nuevaRutina = await Rutina.create(req.userEmail, {
      nombre,
      nivel: nivel || 'Principiante',
      categoria: categoria || 'Fuerza',
      tiempoDescanso: tiempoDescanso || 60,
      tiempoEstimado: tiempoEstimado || 0,
      ejercicios
    });

    console.log('✅ Rutina creada con ID:', nuevaRutina.id);
    res.status(201).json({
      success: true,
      rutina: formatRutina(nuevaRutina)
    });
  } catch (error) {
    console.error('❌ Error al crear rutina:', error);
    res.status(500).json({ error: 'Error al crear rutina' });
  }
});

// ACTUALIZAR RUTINA (edición de nombre / nivel / categoría / ejercicios)
router.put('/:id', authMiddleware, async (req, res) => {
  console.log('✏️ PUT /api/rutinas/:id - Usuario:', req.userEmail);
  try {
    const id = parseInt(req.params.id);
    const { nombre, nivel, categoria, tiempoDescanso, tiempoEstimado, ejercicios } = req.body;

    const actualizada = await Rutina.update(id, req.userEmail, {
      nombre,
      nivel,
      categoria,
      tiempoDescanso,
      tiempoEstimado,
      ejercicios
    });

    if (!actualizada) {
      console.log('❌ Rutina no encontrada o no pertenece al usuario');
      return res.status(404).json({ error: 'Rutina no encontrada' });
    }

    console.log('✅ Rutina actualizada:', id);
    res.json({
      success: true,
      rutina: formatRutina(actualizada)
    });
  } catch (error) {
    console.error('❌ Error al actualizar rutina:', error);
    res.status(500).json({ error: 'Error al actualizar rutina' });
  }
});

// ELIMINAR RUTINA
router.delete('/:id', authMiddleware, async (req, res) => {
  console.log('🗑️ DELETE /api/rutinas/:id - Usuario:', req.userEmail);
  try {
    const id = parseInt(req.params.id);
    console.log(`🗑️ Eliminando rutina ID: ${id}`);

    const deleted = await Rutina.delete(id, req.userEmail);

    if (!deleted) {
      console.log('❌ Rutina no encontrada');
      return res.status(404).json({ error: 'Rutina no encontrada' });
    }

    console.log('✅ Rutina eliminada:', id);
    res.json({
      success: true,
      message: 'Rutina eliminada correctamente'
    });
  } catch (error) {
    console.error('❌ Error al eliminar rutina:', error);
    res.status(500).json({ error: 'Error al eliminar rutina' });
  }
});

module.exports = router;
