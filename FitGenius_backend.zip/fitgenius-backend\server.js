const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { pool, testConnection } = require('./database/connection');
const User = require('./models/User');
const Rutina = require('./models/Rutina');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

const initDatabase = async () => {
  try {
    const connected = await testConnection();
    if (!connected) {
      console.error('❌ No se pudo conectar a la base de datos');
      return;
    }
    
    await User.createTable();
    await Rutina.createTable();
    console.log('✅ Base de datos inicializada correctamente');
  } catch (error) {
    console.error('❌ Error al inicializar base de datos:', error.message);
  }
};

const authRoutes = require('./routes/auth');
const rutinaRoutes = require('./routes/rutinas');

app.use('/api/auth', authRoutes);
app.use('/api/rutinas', rutinaRoutes);

app.get('/', (req, res) => {
  res.json({ 
    message: '🚀 API de FitGenius funcionando!',
    version: '1.0.0',
    database: 'MySQL on Railway'
  });
});

app.listen(PORT, async () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
  await initDatabase();
});

process.on('SIGINT', async () => {
  console.log('\n🛑 Cerrando servidor...');
  await pool.end();
  process.exit(0);
});
