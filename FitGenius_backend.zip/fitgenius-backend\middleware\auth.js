const jwt = require('jsonwebtoken');
require('dotenv').config();

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  console.log('🔑 Headers recibidos:', req.headers);
  
  const token = authHeader?.split(' ')[1];
  
  console.log('🔑 Token recibido:', token ? 'Sí (primeros 20 chars: ' + token.substring(0, 20) + '...)' : 'No');
  
  if (!token) {
    console.log('❌ No hay token');
    return res.status(401).json({ error: 'No autorizado. Token no proporcionado' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userEmail = decoded.email;
    req.userId = decoded.id;
    console.log('✅ Usuario autenticado:', req.userEmail);
    next();
  } catch (error) {
    console.log('❌ Token inválido:', error.message);
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
};

module.exports = authMiddleware;
