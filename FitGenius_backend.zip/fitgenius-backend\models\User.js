const { pool } = require('../database/connection');

class User {
  static async createTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        nombre VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        fecha_nacimiento DATE,
        edad INT,
        peso VARCHAR(50),
        altura VARCHAR(50),
        objetivo VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;
    await pool.query(query);
    console.log('✅ Tabla users creada/verificada');
  }

  static async findByEmail(email) {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [id]);
    return rows[0];
  }

  static async create(userData) {
    const { email, nombre, password, fechaNacimiento, edad, peso, altura, objetivo } = userData;
    const [result] = await pool.query(
      `INSERT INTO users (email, nombre, password, fecha_nacimiento, edad, peso, altura, objetivo)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [email, nombre, password, fechaNacimiento, edad, peso, altura, objetivo]
    );
    return this.findById(result.insertId);
  }

  static async updateProfile(email, data) {
    const { nombre, peso, altura, objetivo } = data;
    const [result] = await pool.query(
      `UPDATE users 
       SET nombre = COALESCE(?, nombre),
           peso = COALESCE(?, peso),
           altura = COALESCE(?, altura),
           objetivo = COALESCE(?, objetivo)
       WHERE email = ?`,
      [nombre, peso, altura, objetivo, email]
    );
    if (result.affectedRows === 0) return null;
    return this.findByEmail(email);
  }

  static async delete(email) {
    const [result] = await pool.query('DELETE FROM users WHERE email = ?', [email]);
    return result.affectedRows > 0;
  }
}

module.exports = User;
