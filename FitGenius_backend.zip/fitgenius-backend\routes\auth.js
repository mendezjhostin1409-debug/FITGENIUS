const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const authMiddleware = require('../middleware/auth');
require('dotenv').config();

router.post('/register', async (req, res) => {
  try {
    const { email, nombre, password, fechaNacimiento, edad, peso, altura, objetivo } = req.body;

    if (!email || !nombre || !password) {
      return res.status(400).json({ error: 'Email, nombre y contraseña son obligatorios' });
    }

    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({ error: 'El email ya está registrado' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await User.create({
      email,
      nombre,
      password: hashedPassword,
      fechaNacimiento: fechaNacimiento || null,
      edad: edad || null,
      peso: peso || null,
      altura: altura || null,
      objetivo: objetivo || null
    });

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      success: true,
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        nombre: newUser.nombre,
        fechaNacimiento: newUser.fecha_nacimiento,
        edad: newUser.edad,
        peso: newUser.peso,
        altura: newUser.altura,
        objetivo: newUser.objetivo
      }
    });
  } catch (error) {
    console.error('Error en registro:', error);
    res.status(500).json({ error: 'Error al registrar usuario' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña son obligatorios' });
    }

    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        nombre: user.nombre,
        fechaNacimiento: user.fecha_nacimiento,
        edad: user.edad,
        peso: user.peso,
        altura: user.altura,
        objetivo: user.objetivo
      }
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({ error: 'Error al iniciar sesión' });
  }
});

router.get('/profile', authMiddleware, async (req, res) => {
  try {
    const user = await User.findByEmail(req.userEmail);
    
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    res.json({
      id: user.id,
      email: user.email,
      nombre: user.nombre,
      fechaNacimiento: user.fecha_nacimiento,
      edad: user.edad,
      peso: user.peso,
      altura: user.altura,
      objetivo: user.objetivo
    });
  } catch (error) {
    console.error('Error en perfil:', error);
    res.status(500).json({ error: 'Error al obtener perfil' });
  }
});

router.put('/profile', authMiddleware, async (req, res) => {
  try {
    const { nombre, peso, altura, objetivo } = req.body;

    const updatedUser = await User.updateProfile(req.userEmail, {
      nombre,
      peso,
      altura,
      objetivo
    });

    if (!updatedUser) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    res.json({
      id: updatedUser.id,
      email: updatedUser.email,
      nombre: updatedUser.nombre,
      fechaNacimiento: updatedUser.fecha_nacimiento,
      edad: updatedUser.edad,
      peso: updatedUser.peso,
      altura: updatedUser.altura,
      objetivo: updatedUser.objetivo
    });
  } catch (error) {
    console.error('Error al actualizar perfil:', error);
    res.status(500).json({ error: 'Error al actualizar perfil' });
  }
});

module.exports = router;
